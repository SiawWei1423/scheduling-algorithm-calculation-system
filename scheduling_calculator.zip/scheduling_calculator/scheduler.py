import tkinter as tk
from tkinter import ttk, messagebox
from collections import deque

# ── Palette ──────────────────────────────────────────────
BG        = '#0F172A'
SIDEBAR   = '#1E293B'
SIDE_DK   = '#0F172A'
CARD      = '#FFFFFF'
SURFACE   = '#F8FAFC'
BD_SIDE   = '#334155'
BD_CARD   = '#E2E8F0'
PRIMARY   = '#6366F1'
PRI_DARK  = '#4338CA'
PRI_GLOW  = '#818CF8'
SUCCESS   = '#10B981'
INFO      = '#3B82F6'
WARN      = '#F59E0B'
DANGER    = '#EF4444'
TXT_DK    = '#1E293B'
TXT_MU    = '#94A3B8'
TXT_LT    = '#F1F5F9'
TXT_WH    = '#FFFFFF'
COLORS = [
    '#6366F1', '#EC4899', '#F59E0B', '#10B981',
    '#3B82F6', '#8B5CF6', '#EF4444', '#06B6D4',
    '#84CC16', '#F97316',
]


def make_btn(parent, text, cmd, fill=PRIMARY, par_bg=SIDEBAR):
    """Styled flat button that works reliably across tkinter versions."""
    btn = tk.Button(
        parent, text=text, command=cmd,
        bg=fill, fg=TXT_WH,
        font=('Segoe UI', 11, 'bold'),
        relief='flat', bd=0,
        padx=22, pady=10,
        cursor='hand2',
        activebackground=PRI_DARK,
        activeforeground=TXT_WH,
        highlightthickness=0,
    )
    btn.bind('<Enter>', lambda e: btn.configure(bg=PRI_DARK))
    btn.bind('<Leave>', lambda e: btn.configure(bg=fill))
    return btn


class App:
    def __init__(self, root):
        self.root = root
        root.title("CPU Scheduling Calculator")
        root.geometry("1280x820")
        root.configure(bg=BG)
        root.resizable(True, True)

        # header
        hdr = tk.Frame(root, bg=PRIMARY, height=62)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        tk.Label(hdr, text="  CPU Scheduling Algorithms Calculator",
                 font=('Segoe UI', 15, 'bold'), bg=PRIMARY, fg=TXT_WH,
                 pady=16).pack(side='left', padx=16)
        tk.Label(hdr, text="Interactive Process Scheduler  ",
                 font=('Segoe UI', 9), bg=PRIMARY, fg=PRI_GLOW,
                 pady=20).pack(side='right', padx=16)

        # styled notebook
        sty = ttk.Style()
        sty.theme_use('clam')
        sty.configure('D.TNotebook', background=BG, borderwidth=0, tabmargins=0)
        sty.configure('D.TNotebook.Tab',
                      background=SIDEBAR, foreground=TXT_MU,
                      font=('Segoe UI', 10, 'bold'),
                      padding=[20, 11], borderwidth=0)
        sty.map('D.TNotebook.Tab',
                background=[('selected', PRIMARY)],
                foreground=[('selected', TXT_WH)],
                expand=[('selected', [0, 0, 0, 0])])

        nb = ttk.Notebook(root, style='D.TNotebook')
        nb.pack(fill='both', expand=True)

        self._fcfs_tab(nb)
        self._rr_tab(nb)
        self._sjf_tab(nb)
        self._priority_tab(nb)

    def _build_input(self, parent, has_priority=False, has_quantum=False):
        from tkinter import colorchooser
        _PAL = ['#84CC16','#EC4899','#06B6D4','#8B5CF6',
                '#F59E0B','#EF4444','#10B981','#3B82F6','#F97316','#6366F1']
        processes = []
        next_id   = [1]

        # ── optional quantum row (RR) ────────────────────────
        q_var = None
        if has_quantum:
            qf = tk.Frame(parent, bg=SIDEBAR)
            qf.pack(fill='x', padx=14, pady=(10, 2))
            tk.Label(qf, text="Time Quantum:", bg=SIDEBAR, fg=TXT_LT,
                     font=('Segoe UI', 10)).pack(side='left')
            q_var = tk.IntVar(value=4)
            tk.Spinbox(qf, from_=1, to=500, textvariable=q_var,
                       width=5, bg=BD_SIDE, fg=TXT_WH, relief='flat',
                       buttonbackground=BD_SIDE, highlightthickness=0,
                       font=('Segoe UI', 10)).pack(side='left', padx=(8, 0))

        # ── scrollable card area ─────────────────────────────
        outer = tk.Frame(parent, bg=SIDEBAR)
        outer.pack(fill='both', expand=True, padx=10, pady=(6, 0))

        cv = tk.Canvas(outer, bg=SIDEBAR, highlightthickness=0)
        vsb = tk.Scrollbar(outer, orient='vertical', command=cv.yview)
        vsb.pack(side='right', fill='y')
        cv.pack(side='left', fill='both', expand=True)
        cv.configure(yscrollcommand=vsb.set)

        cf = tk.Frame(cv, bg=SIDEBAR)
        _cf_win = cv.create_window((0, 0), window=cf, anchor='nw')
        cf.bind('<Configure>', lambda e: cv.configure(scrollregion=cv.bbox('all')))

        # empty-state label
        tk.Label(cf, text="No processes yet.\nClick  + Add Process  to begin.",
                 bg=SIDEBAR, fg=TXT_MU, font=('Segoe UI', 9),
                 justify='center', pady=24).pack(fill='x')

        def render():
            for w in cf.winfo_children():
                w.destroy()
            if not processes:
                tk.Label(cf,
                         text="No processes yet.\nClick  \u002b Add Process  to begin.",
                         bg=SIDEBAR, fg=TXT_MU, font=('Segoe UI', 9),
                         justify='center', pady=24).pack(fill='x')
                return
            for idx, proc in enumerate(processes):
                _make_card(idx, proc)

        def _make_card(idx, proc):
            CBGA = '#152033'
            CBGH = '#1C2E48'

            # outer wrapper holds accent bar + card body
            wrap = tk.Frame(cf, bg=SIDEBAR)
            wrap.pack(fill='x', padx=8, pady=4)
            cf.grid_columnconfigure(0, weight=1)

            # left accent bar (process color)
            tk.Frame(wrap, bg=proc['color'], width=4).pack(side='left', fill='y')

            card = tk.Frame(wrap, bg=CBGA, padx=12, pady=10)
            card.pack(side='left', fill='both', expand=True)

            # top row: circle swatch + name + ✕
            top = tk.Frame(card, bg=CBGA)
            top.pack(fill='x')

            sw = tk.Canvas(top, width=28, height=28, bg=CBGA, highlightthickness=0)
            sw.pack(side='left', padx=(0, 10))
            sw.create_oval(2, 2, 26, 26, fill=proc['color'], outline='')

            tk.Label(top, text=f"Process {proc['id']}", bg=CBGA,
                     fg=TXT_WH, font=('Segoe UI', 10, 'bold')).pack(side='left')

            def _del(target_id=proc['id']):
                # remove by id — avoids equality issues with same-value dicts
                for i, x in enumerate(processes):
                    if x['id'] == target_id:
                        processes.pop(i)
                        break
                # renumber remaining so IDs stay sequential
                for i, x in enumerate(processes):
                    x['id'] = i + 1
                next_id[0] = len(processes) + 1
                render()

            xl = tk.Label(top, text='  ✕', bg=CBGA, fg='#475569',
                          font=('Segoe UI', 10), cursor='hand2')
            xl.pack(side='right')
            xl.bind('<Button-1>', lambda e, fn=_del: (fn(), 'break'))
            xl.bind('<Enter>', lambda e: xl.configure(fg=DANGER, bg=CBGH))
            xl.bind('<Leave>', lambda e: xl.configure(fg='#475569', bg=CBGA))

            # details row
            det = tk.Frame(card, bg=CBGA)
            det.pack(fill='x', pady=(6, 0))

            def _kv(parent, key, val):
                f = tk.Frame(parent, bg=CBGA)
                f.pack(side='left', padx=(0, 16))
                tk.Label(f, text=key, bg=CBGA, fg='#64748B',
                         font=('Segoe UI', 8)).pack(anchor='w')
                tk.Label(f, text=str(val), bg=CBGA, fg=TXT_LT,
                         font=('Segoe UI', 10, 'bold')).pack(anchor='w')

            _kv(det, 'ARRIVAL', proc['arrival'])
            _kv(det, 'BURST',   proc['burst'])
            if has_priority:
                _kv(det, 'PRIORITY', proc.get('priority', 1))

            # hover effect on card
            def _hover_in(e):  card.configure(bg=CBGH); top.configure(bg=CBGH); det.configure(bg=CBGH); sw.configure(bg=CBGH)
            def _hover_out(e): card.configure(bg=CBGA); top.configure(bg=CBGA); det.configure(bg=CBGA); sw.configure(bg=CBGA)
            for w in [card, top, det]:
                w.bind('<Enter>', _hover_in)
                w.bind('<Leave>', _hover_out)

        def open_add_form():
            pop = tk.Toplevel(parent)
            pop.title("")
            pop.overrideredirect(False)
            pop.configure(bg=SIDE_DK)
            h = 460 if has_priority else 420
            pop.geometry(f"380x{h}")
            pop.resizable(False, False)
            pop.grab_set()

            # ── header bar ──────────────────────────────────
            hdr = tk.Frame(pop, bg=PRIMARY, height=52)
            hdr.pack(fill='x')
            hdr.pack_propagate(False)
            tk.Label(hdr, text="  + Add Process", bg=PRIMARY, fg=TXT_WH,
                     font=('Segoe UI', 12, 'bold'), pady=14).pack(side='left')
            cl = tk.Label(hdr, text='✕  ', bg=PRIMARY, fg=PRI_GLOW,
                          font=('Segoe UI', 11), cursor='hand2', pady=14)
            cl.pack(side='right')
            cl.bind('<Button-1>', lambda e: pop.destroy())
            cl.bind('<Enter>',   lambda e: cl.configure(fg=TXT_WH))
            cl.bind('<Leave>',   lambda e: cl.configure(fg=PRI_GLOW))

            body = tk.Frame(pop, bg=SIDE_DK)
            body.pack(fill='both', expand=True)

            chosen = [_PAL[(next_id[0] - 1) % len(_PAL)]]

            def _field(lbl, default='0'):
                tk.Label(body, text=lbl, bg=SIDE_DK, fg=TXT_MU,
                         font=('Segoe UI', 9, 'bold')).pack(anchor='w', padx=24, pady=(16, 4))
                v = tk.StringVar(value=default)
                ef = tk.Frame(body, bg=BD_SIDE, highlightthickness=1,
                              highlightbackground=BD_SIDE, highlightcolor=PRIMARY)
                ef.pack(fill='x', padx=24)
                e = tk.Entry(ef, textvariable=v, bg=BD_SIDE, fg=TXT_WH,
                             insertbackground=PRI_GLOW, relief='flat',
                             font=('Segoe UI', 11), bd=0)
                e.pack(fill='x', padx=10, ipady=9)
                e.bind('<FocusIn>',  lambda ev: ef.configure(highlightbackground=PRIMARY))
                e.bind('<FocusOut>', lambda ev: ef.configure(highlightbackground=BD_SIDE))
                return v

            arr_v  = _field("ARRIVAL TIME", '0')
            bst_v  = _field("BURST TIME",   '1')
            prio_v = _field("PRIORITY  (1 = Highest)", '1') if has_priority else None

            # ── color section ────────────────────────────────
            tk.Label(body, text="PROCESS COLOR", bg=SIDE_DK, fg=TXT_MU,
                     font=('Segoe UI', 9, 'bold')).pack(anchor='w', padx=24, pady=(16, 8))

            # palette quick-picks
            prow = tk.Frame(body, bg=SIDE_DK)
            prow.pack(anchor='w', padx=24)
            sel_dot = [None]

            def _select_color(col, dot):
                chosen[0] = col
                clbl.configure(text=col)
                # reset all dots border
                for d in all_dots:
                    d.configure(highlightbackground=SIDE_DK)
                dot.configure(highlightbackground=TXT_WH)

            all_dots = []
            for pc in _PAL:
                dot = tk.Label(prow, bg=pc, width=2, height=1,
                               cursor='hand2', relief='flat',
                               highlightthickness=2, highlightbackground=SIDE_DK)
                dot.pack(side='left', padx=2)
                all_dots.append(dot)
                dot.bind('<Button-1>', lambda e, c=pc, d=dot: _select_color(c, d))
                dot.bind('<Enter>',    lambda e, d=dot: d.configure(highlightbackground=TXT_WH))
                dot.bind('<Leave>',    lambda e, d=dot, c=chosen:
                         d.configure(highlightbackground=TXT_WH if d['bg']==c[0] else SIDE_DK))
            # mark default selected
            all_dots[(next_id[0]-1) % len(_PAL)].configure(highlightbackground=TXT_WH)

            # custom picker row
            crow = tk.Frame(body, bg=SIDE_DK)
            crow.pack(anchor='w', padx=24, pady=(10, 0))
            sw = tk.Canvas(crow, width=24, height=24, bg=SIDE_DK, highlightthickness=0)
            sw.pack(side='left')
            sw.create_oval(2, 2, 22, 22, fill=chosen[0], outline='')
            clbl = tk.Label(crow, text=chosen[0], bg=SIDE_DK, fg=TXT_MU,
                            font=('Segoe UI', 9))
            clbl.pack(side='left', padx=8)

            def pick():
                c = colorchooser.askcolor(color=chosen[0], parent=pop)
                if c and c[1]:
                    chosen[0] = c[1]
                    sw.delete('all')
                    sw.create_oval(2, 2, 22, 22, fill=c[1], outline='')
                    clbl.configure(text=c[1])
                    for d in all_dots:
                        d.configure(highlightbackground=SIDE_DK)

            tk.Button(crow, text="Custom…", command=pick,
                      bg=BD_SIDE, fg=TXT_MU, relief='flat',
                      padx=10, pady=3, cursor='hand2',
                      activebackground=PRIMARY, activeforeground=TXT_WH,
                      font=('Segoe UI', 9), highlightthickness=0
                      ).pack(side='left', padx=6)

            def submit():
                try:
                    p = {'id': next_id[0],
                         'arrival': int(arr_v.get()),
                         'burst':   int(bst_v.get()),
                         'color':   chosen[0]}
                    if p['burst'] <= 0:
                        raise ValueError
                    if prio_v:
                        p['priority'] = int(prio_v.get())
                    processes.append(p)
                    next_id[0] += 1
                    render()
                    pop.destroy()
                except ValueError:
                    pass

            # ── submit bar ───────────────────────────────────
            sub_bar = tk.Frame(pop, bg=BD_SIDE)
            sub_bar.pack(fill='x', side='bottom')
            sb_btn = tk.Button(sub_bar, text="  Submit  ", command=submit,
                               bg=PRIMARY, fg=TXT_WH, relief='flat',
                               font=('Segoe UI', 11, 'bold'), pady=13,
                               cursor='hand2', activebackground=PRI_DARK,
                               activeforeground=TXT_WH, bd=0,
                               highlightthickness=0)
            sb_btn.pack(fill='x')
            sb_btn.bind('<Enter>', lambda e: sb_btn.configure(bg=PRI_DARK))
            sb_btn.bind('<Leave>', lambda e: sb_btn.configure(bg=PRIMARY))

        def clear_all():
            processes.clear()
            next_id[0] = 1
            render()

        # ── bottom buttons ───────────────────────────────────
        tk.Frame(parent, bg=BD_SIDE, height=1).pack(fill='x')
        bf = tk.Frame(parent, bg=SIDEBAR)
        bf.pack(fill='x', padx=12, pady=10)

        add_btn = tk.Button(bf, text="＋  Add Process", command=open_add_form,
                            bg=PRIMARY, fg=TXT_WH, relief='flat',
                            font=('Segoe UI', 10, 'bold'), pady=10,
                            cursor='hand2', activebackground=PRI_DARK,
                            activeforeground=TXT_WH, highlightthickness=0)
        add_btn.pack(fill='x', pady=(0, 6))
        add_btn.bind('<Enter>', lambda e: add_btn.configure(bg=PRI_DARK))
        add_btn.bind('<Leave>', lambda e: add_btn.configure(bg=PRIMARY))

        clr_btn = tk.Button(bf, text="Clear all processes", command=clear_all,
                            bg=SIDEBAR, fg='#475569', relief='flat', bd=0,
                            font=('Segoe UI', 9), pady=8,
                            cursor='hand2', activebackground=BD_SIDE,
                            activeforeground=DANGER, highlightthickness=1,
                            highlightbackground=BD_SIDE)
        clr_btn.pack(fill='x')
        clr_btn.bind('<Enter>', lambda e: clr_btn.configure(fg=DANGER, highlightbackground=DANGER))
        clr_btn.bind('<Leave>', lambda e: clr_btn.configure(fg='#475569', highlightbackground=BD_SIDE))

        def read():
            if not processes:
                raise ValueError("No processes added")
            return [dict(p) for p in processes]

        return read, q_var

    def _build_output(self, parent):
        # Gantt section
        gh = tk.Frame(parent, bg=CARD)
        gh.pack(fill='x', padx=0)
        tk.Label(gh, text="  Gantt Chart",
                 font=('Segoe UI', 10, 'bold'), bg=SIDE_DK, fg=PRI_GLOW,
                 pady=8).pack(fill='x')
        gf = tk.Frame(parent, bg=CARD, bd=0)
        gf.pack(fill='x', padx=0)
        hs = tk.Scrollbar(gf, orient='horizontal', bg=BD_CARD)
        hs.pack(side='bottom', fill='x')
        gc = tk.Canvas(gf, height=100, bg=CARD, xscrollcommand=hs.set,
                       highlightthickness=0)
        gc.pack(fill='x')
        hs.config(command=gc.xview)

        # separator
        tk.Frame(parent, bg=BD_CARD, height=1).pack(fill='x', pady=(6, 0))

        # Results section
        tk.Label(parent, text="  Results",
                 font=('Segoe UI', 10, 'bold'), bg=SIDE_DK, fg=PRI_GLOW,
                 pady=8).pack(fill='x')
        rf_outer = tk.Frame(parent, bg=CARD)
        rf_outer.pack(fill='both', expand=True)
        vs = tk.Scrollbar(rf_outer, bg=BD_CARD)
        vs.pack(side='right', fill='y')
        rc = tk.Canvas(rf_outer, bg=CARD, yscrollcommand=vs.set,
                       highlightthickness=0)
        rc.pack(side='left', fill='both', expand=True)
        vs.config(command=rc.yview)
        rf = tk.Frame(rc, bg=CARD)
        rc.create_window((0, 0), window=rf, anchor='nw')
        rf.bind('<Configure>', lambda e: rc.configure(scrollregion=rc.bbox('all')))

        return gc, rf

    def _draw_gantt(self, canvas, gantt):
        # cancel any in-progress animation
        if hasattr(canvas, '_anim_id') and canvas._anim_id:
            canvas.after_cancel(canvas._anim_id)
            canvas._anim_id = None
        canvas.delete('all')
        if not gantt:
            return

        total = gantt[-1][1]
        pids  = sorted(set(g[2] for g in gantt))
        cmap  = {pid: COLORS[(pid - 1) % len(COLORS)] for pid in pids}
        px    = max(22, 860 // max(total, 1))
        W     = 60 + total * px + 60
        canvas.configure(scrollregion=(0, 0, W, 100), bg=CARD)
        bar_y, bar_h, R = 14, 50, 6

        # ── draw static time-tick markers ──────────────────
        shown = set()
        for s, e, _ in gantt:
            for t in (s, e):
                if t not in shown:
                    x = 44 + t * px
                    canvas.create_line(x, bar_y + bar_h + 2, x, bar_y + bar_h + 8,
                                       fill=TXT_MU, width=1, tags='ticks')
                    canvas.create_text(x, bar_y + bar_h + 18, text=str(t),
                                       font=('Segoe UI', 8), fill=TXT_DK, tags='ticks')
                    shown.add(t)

        # ── animation parameters (auto-scale to ~1.2 s total) ──
        n_bars  = max(len(gantt), 1)
        STEPS   = 14                          # frames per bar
        PAUSE   = 18                          # ms gap between bars
        DELAY   = max(5, (1200 - PAUSE * n_bars) // (STEPS * n_bars))

        def _draw_frame(x1, x2_cur, col, tag):
            """Redraw one bar at its current animated width."""
            canvas.delete(tag)
            w  = x2_cur - x1
            if w < 2:
                return
            rr = min(R, int(w // 2))
            # shadow
            canvas.create_rectangle(
                x1 + 2, bar_y + 2, x2_cur + 2, bar_y + bar_h + 2,
                fill='#CBD5E1', outline='', tags=tag)
            # rounded bar
            canvas.create_polygon(
                x1+rr, bar_y,        x2_cur-rr, bar_y,
                x2_cur, bar_y,       x2_cur, bar_y+rr,
                x2_cur, bar_y+bar_h-rr, x2_cur, bar_y+bar_h,
                x2_cur-rr, bar_y+bar_h, x1+rr, bar_y+bar_h,
                x1, bar_y+bar_h,     x1, bar_y+bar_h-rr,
                x1, bar_y+rr,        x1, bar_y,
                smooth=True, fill=col, outline='', tags=tag)
            # gloss strip
            if w > 10:
                canvas.create_rectangle(
                    x1+rr, bar_y, x2_cur-rr, bar_y + 6,
                    fill='white', outline='', stipple='gray25', tags=tag)

        def _animate(idx, step):
            if idx >= len(gantt):
                return
            s, e, pid = gantt[idx]
            col   = cmap[pid]
            x1    = 44 + s * px
            x2_full = 44 + e * px
            tag   = f'_bar{idx}'

            # ease-out cubic: fast start → gentle stop
            t_norm = step / STEPS
            ease   = 1 - (1 - t_norm) ** 3
            x2_cur = x1 + (x2_full - x1) * ease

            _draw_frame(x1, x2_cur, col, tag)

            if step < STEPS:
                canvas._anim_id = canvas.after(
                    DELAY, lambda: _animate(idx, step + 1))
            else:
                # finalize: draw exact final frame + label
                _draw_frame(x1, x2_full, col, tag)
                if x2_full - x1 >= 20:
                    canvas.create_text(
                        (x1 + x2_full) / 2, bar_y + bar_h / 2,
                        text=f'P{pid}', fill=TXT_WH,
                        font=('Segoe UI', 9, 'bold'), tags=tag)
                # move to next bar after a short pause
                canvas._anim_id = canvas.after(
                    PAUSE, lambda: _animate(idx + 1, 0))

        canvas._anim_id = None
        _animate(0, 0)

    def _show_results(self, gc, rf, procs, gantt, extra_text=''):
        self._draw_gantt(gc, gantt)
        for w in rf.winfo_children():
            w.destroy()

        n = len(procs)
        tw = tc = 0
        for p in procs:
            tw += p['wt']
            tc += p['ct']

        # ── Two-column row: table (left) + avg cards (right) ──
        row = tk.Frame(rf, bg=CARD)
        row.pack(fill='x', pady=(10, 0), padx=10)

        # LEFT — results table
        t = tk.Frame(row, bg='black')
        t.pack(side='left', anchor='n')

        hdrs = ['Process', 'Arrival', 'Burst', 'Completion', 'Waiting', 'Turnaround']
        hdr_cols = [PRIMARY, '#EC4899', '#F59E0B', SUCCESS, INFO, '#8B5CF6']
        for c, (h, hc) in enumerate(zip(hdrs, hdr_cols)):
            tk.Label(t, text=h, font=('Segoe UI', 9, 'bold'),
                     bg=hc, fg=TXT_WH, width=11, pady=7
                     ).grid(row=0, column=c, padx=1, pady=1)

        for i, p in enumerate(procs):
            tat = p['ct'] - p['arrival']
            rbg = '#F0F4F8' if i % 2 == 0 else CARD
            pid_col = COLORS[(p['id'] - 1) % len(COLORS)]
            tk.Label(t, text=f"P{p['id']}", bg=pid_col, fg=TXT_WH,
                     width=11, pady=6, font=('Segoe UI', 9, 'bold')
                     ).grid(row=i + 1, column=0, padx=1, pady=1)
            for c, v in enumerate([p['arrival'], p['burst'], p['ct'], p['wt'], tat], 1):
                tk.Label(t, text=str(v), bg=rbg, fg=TXT_DK,
                         width=11, pady=6, font=('Segoe UI', 9)
                         ).grid(row=i + 1, column=c, padx=1, pady=1)

        # RIGHT — avg cards, same height as table
        rside = tk.Frame(row, bg=CARD)
        rside.pack(side='left', fill='y', padx=(10, 0))

        wt_card = tk.Frame(rside, bg=INFO, padx=16, pady=10)
        wt_card.pack(side='left', fill='both', expand=True, padx=(0, 6))
        tk.Label(wt_card, text="AVG WAITING TIME",
                 font=('Segoe UI', 8, 'bold'), bg=INFO, fg='#DBEAFE').pack(expand=True)
        tk.Label(wt_card, text=f"{tw / n:.2f}",
                 font=('Segoe UI', 20, 'bold'), bg=INFO, fg=TXT_WH).pack(expand=True)

        ct_card = tk.Frame(rside, bg=SUCCESS, padx=16, pady=10)
        ct_card.pack(side='left', fill='both', expand=True)
        tk.Label(ct_card, text="AVG COMPLETION TIME",
                 font=('Segoe UI', 8, 'bold'), bg=SUCCESS, fg='#D1FAE5').pack(expand=True)
        tk.Label(ct_card, text=f"{tc / n:.2f}",
                 font=('Segoe UI', 20, 'bold'), bg=SUCCESS, fg=TXT_WH).pack(expand=True)

        # ── Calculation Steps ────────────────────────────────
        sf2 = tk.Frame(rf, bg=CARD)
        sf2.pack(fill='x', padx=10, pady=(0, 16))

        # section header
        hdr_row = tk.Frame(sf2, bg=CARD)
        hdr_row.pack(fill='x', pady=(0, 6))
        tk.Label(hdr_row, text="Calculation Steps",
                 font=('Segoe UI', 11, 'bold'), bg=CARD, fg=TXT_DK).pack(side='left')
        tk.Frame(sf2, bg='black', height=1).pack(fill='x', pady=(0, 10))

        def _steps_block(parent, label, color, values_dict, total, n_proc):
            """Render one block: per-process badges + formula line."""
            blk = tk.Frame(parent, bg='#F8FAFC', padx=14, pady=12)
            blk.pack(fill='x', pady=(0, 8))

            # block title
            tk.Label(blk, text=label, font=('Segoe UI', 9, 'bold'),
                     bg='#F8FAFC', fg=color).pack(anchor='w', pady=(0, 8))

            # per-process row
            badge_row = tk.Frame(blk, bg='#F8FAFC')
            badge_row.pack(anchor='w', pady=(0, 8))
            for pid, val in values_dict.items():
                badge = tk.Frame(badge_row, bg=color, padx=8, pady=4)
                badge.pack(side='left', padx=(0, 6))
                tk.Label(badge, text=f"P{pid}",
                         font=('Segoe UI', 8, 'bold'), bg=color, fg=TXT_WH).pack()
                tk.Label(badge, text=str(val),
                         font=('Segoe UI', 11, 'bold'), bg=color, fg=TXT_WH).pack()

            # formula line
            parts = list(values_dict.values())
            formula_parts = ' + '.join(str(v) for v in parts)
            formula = f"( {formula_parts} )  ÷  {n_proc}  =  {total / n_proc:.2f}"
            tk.Label(blk, text=formula,
                     font=('Courier New', 10, 'bold'), bg='#F8FAFC', fg=TXT_DK,
                     justify='left').pack(anchor='w')

        wt_vals = {p['id']: p['wt'] for p in procs}
        ct_vals = {p['id']: p['ct'] for p in procs}

        _steps_block(sf2, "Waiting Time per Process", INFO,  wt_vals, tw, n)
        _steps_block(sf2, "Completion Time per Process", SUCCESS, ct_vals, tc, n)

        if extra_text:
            ef = tk.Frame(rf, bg='#FFF1F2', bd=0)
            ef.pack(fill='x', padx=10, pady=(0, 10))
            tk.Label(ef, text=extra_text, font=('Segoe UI', 9),
                     bg='#FFF1F2', fg=DANGER, wraplength=700,
                     justify='left', padx=12, pady=10
                     ).pack(fill='x')

    # ────────────────────────────────────────────────────────────
    #  Algorithms
    # ────────────────────────────────────────────────────────────
    def _algo_fcfs(self, processes):
        ps = sorted([dict(p) for p in processes],
                    key=lambda x: (x['arrival'], x['id']))
        t = 0
        gantt = []
        for p in ps:
            s = max(t, p['arrival'])
            t = s + p['burst']
            p['ct'] = t
            p['wt'] = s - p['arrival']
            gantt.append((s, t, p['id']))
        return ps, gantt

    def _algo_rr(self, processes, quantum):
        ps = {p['id']: dict(p) for p in processes}
        rem = {pid: p['burst'] for pid, p in ps.items()}
        order = sorted(ps.keys(), key=lambda pid: ps[pid]['arrival'])
        t = 0
        queue = deque()
        gantt = []
        idx = 0
        n = len(order)
        done = 0
        inq = set()

        while done < n:
            while idx < n and ps[order[idx]]['arrival'] <= t:
                pid = order[idx]
                if rem[pid] > 0 and pid not in inq:
                    queue.append(pid)
                    inq.add(pid)
                idx += 1
            if not queue:
                if idx < n:
                    t = ps[order[idx]]['arrival']
                continue
            pid = queue.popleft()
            inq.discard(pid)
            run = min(quantum, rem[pid])
            gantt.append((t, t + run, pid))
            t += run
            rem[pid] -= run
            while idx < n and ps[order[idx]]['arrival'] <= t:
                apid = order[idx]
                if rem[apid] > 0 and apid not in inq:
                    queue.append(apid)
                    inq.add(apid)
                idx += 1
            if rem[pid] == 0:
                ps[pid]['ct'] = t
                ps[pid]['wt'] = t - ps[pid]['arrival'] - ps[pid]['burst']
                done += 1
            else:
                queue.append(pid)
                inq.add(pid)

        return sorted(ps.values(), key=lambda x: x['id']), gantt

    def _algo_sjf(self, processes, preemptive=False):
        ps = [dict(p) for p in processes]
        n = len(ps)
        rem = {p['id']: p['burst'] for p in ps}
        done = set()
        gantt = []
        t = 0
        comp = 0

        if not preemptive:
            while comp < n:
                avail = [p for p in ps if p['arrival'] <= t and p['id'] not in done]
                if not avail:
                    t = min(p['arrival'] for p in ps if p['id'] not in done)
                    continue
                p = min(avail, key=lambda x: (x['burst'], x['id']))
                s = t
                t += p['burst']
                p['ct'] = t
                p['wt'] = s - p['arrival']
                gantt.append((s, t, p['id']))
                done.add(p['id'])
                comp += 1
        else:
            last_pid = None
            seg_s = 0
            while comp < n:
                avail = [p for p in ps if p['arrival'] <= t and p['id'] not in done]
                if not avail:
                    t = min(p['arrival'] for p in ps if p['id'] not in done)
                    last_pid = None
                    continue
                p = min(avail, key=lambda x: (rem[x['id']], x['id']))
                if p['id'] != last_pid:
                    if last_pid is not None:
                        gantt.append((seg_s, t, last_pid))
                    seg_s = t
                    last_pid = p['id']
                future = [q['arrival'] for q in ps
                          if q['arrival'] > t and q['id'] not in done]
                step = min(rem[p['id']],
                           (min(future) - t) if future else rem[p['id']])
                rem[p['id']] -= step
                t += step
                if rem[p['id']] == 0:
                    gantt.append((seg_s, t, p['id']))
                    p['ct'] = t
                    p['wt'] = t - p['arrival'] - p['burst']
                    done.add(p['id'])
                    comp += 1
                    last_pid = None

        return sorted(ps, key=lambda x: x['id']), gantt

    def _algo_priority(self, processes):
        ps = [dict(p) for p in processes]
        n = len(ps)
        t = 0
        gantt = []
        done = set()
        comp = 0
        while comp < n:
            avail = [p for p in ps if p['arrival'] <= t and p['id'] not in done]
            if not avail:
                t = min(p['arrival'] for p in ps if p['id'] not in done)
                continue
            p = min(avail, key=lambda x: (x['priority'], x['id']))
            s = t
            t += p['burst']
            p['ct'] = t
            p['wt'] = s - p['arrival']
            gantt.append((s, t, p['id']))
            done.add(p['id'])
            comp += 1
        return sorted(ps, key=lambda x: x['id']), gantt

    # ────────────────────────────────────────────────────────────
    #  Tab builders
    # ────────────────────────────────────────────────────────────
    def _tab_frame(self, nb, label):
        tab = tk.Frame(nb, bg=BG)
        left = tk.Frame(tab, bg=SIDEBAR, width=420)
        left.pack(side='left', fill='y')
        left.pack_propagate(False)
        # thin separator line
        tk.Frame(tab, bg=BD_SIDE, width=1).pack(side='left', fill='y')
        right = tk.Frame(tab, bg=CARD)
        right.pack(side='left', fill='both', expand=True)
        # left header
        lh = tk.Frame(left, bg=SIDE_DK)
        lh.pack(fill='x')
        tk.Label(lh, text=f"  {label}", font=('Segoe UI', 11, 'bold'),
                 bg=SIDE_DK, fg=TXT_LT, pady=14).pack(side='left')
        return tab, left, right

    def _fcfs_tab(self, nb):
        tab, left, right = self._tab_frame(nb, "First Come First Served (FCFS)")
        nb.add(tab, text='  FCFS  ')
        tk.Label(left,
                 text="  Non-preemptive. Processes run in arrival order.",
                 font=('Segoe UI', 9), bg='#EF4444', fg=TXT_WH,
                 padx=8, pady=6, justify='left').pack(fill='x')
        read, _ = self._build_input(left)
        gc, rf = self._build_output(right)

        def run():
            try:
                p, g = self._algo_fcfs(read())
                self._show_results(gc, rf, p, g)
            except ValueError:
                messagebox.showerror("Input Error", "Enter valid integers in all fields.")

        tk.Frame(left, bg=SIDEBAR, height=6).pack()
        make_btn(left, '  ▶  Calculate', run).pack(pady=12)

    def _rr_tab(self, nb):
        tab, left, right = self._tab_frame(nb, "Round Robin (RR)")
        nb.add(tab, text='  Round Robin  ')
        tk.Label(left,
                 text="  Preemptive. Each process gets a fixed time quantum.",
                 font=('Segoe UI', 9), bg='#8B5CF6', fg=TXT_WH,
                 padx=8, pady=6, justify='left').pack(fill='x')
        read, q_var = self._build_input(left, has_quantum=True)
        gc, rf = self._build_output(right)

        def run():
            try:
                p, g = self._algo_rr(read(), q_var.get())
                self._show_results(gc, rf, p, g)
            except ValueError:
                messagebox.showerror("Input Error", "Enter valid integers in all fields.")

        tk.Frame(left, bg=SIDEBAR, height=6).pack()
        make_btn(left, '  ▶  Calculate', run, fill='#8B5CF6').pack(pady=12)

    def _sjf_tab(self, nb):
        tab, left, right = self._tab_frame(nb, "SJF / STCF / SRTF")
        nb.add(tab, text='  SJF / SRTF  ')
        tk.Label(left,
                 text="  SJF: shortest burst first (non-preemptive).\n  SRTF: preempts if shorter job arrives.",
                 font=('Segoe UI', 9), bg=INFO, fg=TXT_WH,
                 padx=8, pady=6, justify='left').pack(fill='x')

        mode_var = tk.StringVar(value='sjf')

        mf = tk.Frame(left, bg=SIDEBAR)
        mf.pack(fill='x', padx=14, pady=(10, 6))
        tk.Label(mf, text="Mode", bg=SIDEBAR, fg=TXT_MU,
                 font=('Segoe UI', 8, 'bold')).pack(anchor='w', pady=(0, 6))

        seg = tk.Frame(mf, bg=BD_SIDE)
        seg.pack(anchor='w')

        _seg_btns = {}

        def _select_mode(val):
            mode_var.set(val)
            for v, btn in _seg_btns.items():
                if v == val:
                    btn.configure(bg=INFO, fg=TXT_WH,
                                  font=('Segoe UI', 10, 'bold'))
                else:
                    btn.configure(bg=BD_SIDE, fg=TXT_MU,
                                  font=('Segoe UI', 10))

        for txt, val in [('  SJF  ', 'sjf'), ('  SRTF  ', 'srtf')]:
            btn = tk.Button(seg, text=txt, command=lambda v=val: _select_mode(v),
                            bg=BD_SIDE, fg=TXT_MU, relief='flat', bd=0,
                            font=('Segoe UI', 10), pady=7, padx=4,
                            cursor='hand2', activebackground=INFO,
                            activeforeground=TXT_WH, highlightthickness=0)
            btn.pack(side='left')
            _seg_btns[val] = btn

        _select_mode('sjf')  # set initial active state

        read, _ = self._build_input(left)
        gc, rf = self._build_output(right)

        def run():
            try:
                p, g = self._algo_sjf(read(), mode_var.get() == 'srtf')
                self._show_results(gc, rf, p, g)
            except ValueError:
                messagebox.showerror("Input Error", "Enter valid integers in all fields.")

        tk.Frame(left, bg=SIDEBAR, height=6).pack()
        make_btn(left, '  ▶  Calculate', run, fill=INFO).pack(pady=12)

    def _priority_tab(self, nb):
        tab, left, right = self._tab_frame(nb, "Priority Scheduling / Inversion")
        nb.add(tab, text='  Priority  ')
        tk.Label(left,
                 text="  Lower number = Higher priority.\n  Priority Inversion is auto-detected.",
                 font=('Segoe UI', 9), bg=SUCCESS, fg=TXT_WH,
                 padx=8, pady=6, justify='left').pack(fill='x')

        read, _ = self._build_input(left, has_priority=True)
        gc, rf = self._build_output(right)

        def run():
            try:
                procs = read()
                p, g = self._algo_priority(procs)
                inv_msgs = []
                for a in p:
                    for b in p:
                        if (a['priority'] < b['priority']
                                and a['wt'] > b['wt']
                                and a['arrival'] <= b['arrival']):
                            inv_msgs.append(
                                f"P{a['id']} (priority {a['priority']}) arrived first but "
                                f"waited longer than P{b['id']} (priority {b['priority']}) "
                                f"\u2014 Priority Inversion!"
                            )
                extra = ""
                if inv_msgs:
                    extra = "\u26a0 Priority Inversion Detected:\n" + "\n".join(inv_msgs)
                self._show_results(gc, rf, p, g, extra_text=extra)
            except ValueError:
                messagebox.showerror("Input Error", "Enter valid integers in all fields.")

        tk.Frame(left, bg=SIDEBAR, height=6).pack()
        make_btn(left, '  ▶  Calculate', run, fill=SUCCESS).pack(pady=12)


if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.mainloop()
